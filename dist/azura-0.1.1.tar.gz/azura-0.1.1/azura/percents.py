from math import radians, cos, sin, asin, sqrt



def Solve_PercentWhole(part,whole):
    answer = part/whole
    return answer

def PercentChange(point1,point2):
    answer = point1 + point2
    answer = answer/2
    return answer


def Solve_PercentPart(percent,whole):
    answer = percent/100
    answer = answer * whole
    return answer