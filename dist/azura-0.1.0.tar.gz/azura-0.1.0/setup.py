# Always prefer setuptools over distutils
from setuptools import setup, find_packages

# To use a consistent encoding
from codecs import open
from os import path

# The directory containing this file
HERE = path.abspath(path.dirname(__file__))

# Get the long description from the README file
with open(path.join(HERE, 'venv/README.md'), encoding='utf-8') as f:
    long_description = f.read()

# This call to setup() does all the work
setup(
    name="azura",
    version="0.1.0",
    description="Azura is an extreme add-on to the build in math library. Azura focuses on geometry and geometric calculations. Made by Laksh Patel, usable for free but cannot be distributed as your own.",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="",
    author="Laksh Patel",
    author_email="laksh2008patel@gmail.com",
    license="MIT",
    classifiers=[
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Operating System :: OS Independent"
    ],
    packages=["azura"],
    include_package_data=True,
    install_requires=["numpy"]
)